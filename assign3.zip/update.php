<html>
<head>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"
          integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <link rel="stylesheet" href="wishlist.css">
</head>
<body>
<?php
include('assign2db.php');
?>
<div class="container-fluid">
    <div class="head">
        <h1>My Books Wishlist</h1>
    </div>

    <div class="col-md-6 image">
        <img src="http://images.gr-assets.com/quotes/1392103489p8/7572.jpg" alt="quote">
    </div>

    <div class="col-md-2"></div>
        <?php
        $name = $author = $path = $rat = $id = "";
        $nameErr = $autErr = $pErr = $ratErr = "";
        $valid = true;
        if (isset($_GET['update'])) {
            $id = $_GET['id'];
            $name = $_GET['name'];
            $author = $_GET['author'];
            $path = $_GET['path'];
            $rat = $_GET['rating'];

            if (!preg_match("/^[a-zA-z \-\.]*$/", $name) or empty($name)) {
                $nameErr = "Book name required (Only letters, whitespaces or -)";
                $valid = false;
            }
            if (!preg_match("/^[a-zA-z ]*$/", $author) or empty($author)) {
                $autErr = "Author name required with only letters";
                $valid = false;
            }
            if (!preg_match("/^[1-5]{1}$/", $rat)) {
                $ratErr = "Invalid rating";
                $valid = false;
            }

            if ($valid) {
                $query = "update books set id='$id', name='$name', author='$author', review='$rat', image='$path' where id=".$id;
                if (!mysqli_query($conn, $query))
                    echo mysqli_error($conn)." error here";
            else {
                    ?>

                    <div class="col-md-4 success">
                        <h1>Updated :)</h1>
                    </div>
                    <?php
                }
            }
        }
        ?>
    <?php
    $prevId = "";
    if (isset($_GET['up'])) {
        $prevId = $_GET['id1'];
        $record = "select * from books where id=".$prevId;
        $row = mysqli_query($conn, $record);
        $row = mysqli_fetch_array($row);
        if (!$row)
            echo mysqli_error($conn);
        else{
            $id = $row['id'];
            $name = $row ['name'];
            $author = $row['author'];
            $rat = $row ['review'];
            $path = $row['image'];
        }
    }
        ?>
        <form action="update.php" class="form-horizontal col-md-4 form" method="get">
            <input type="hidden" value="<?php echo $prevId ?>" name="prevID">
            <input type="text" value="<?php echo $id ?>" class="form-control"  name="id" required readonly><br>
            <input type="text" value="<?php echo $name ?>" class="form-control" placeholder="book name" name="name" required><span><?php echo $nameErr ?></span> <br>
            <input type="text" value="<?php echo $author ?>" class="form-control" placeholder="author" name="author" required><span><?php echo $autErr ?></span> <br>
            <input type="text" value="<?php echo $rat ?>" class="form-control" placeholder="rating (1 to 5)" name="rating"><span><?php echo $ratErr ?></span> <br>
            <input type="text" value="<?php echo $path ?>" class="form-control" placeholder="image path" name="path" required><br>
            <button type="submit" class="btn btn-success" name="update">Update</button>
        </form>
</body>
</html>