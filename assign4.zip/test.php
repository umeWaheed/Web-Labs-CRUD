<?php
include('simple_html_dom.php');
include ('db.php');

$html = file_get_html('http://webscripts.softpedia.com/blog/');

foreach ($html->find('a[class=title]') as $element) {
    $val = $element->href;
    echo $val. '<br>';
    $query = "insert into links value ('$val')";
    mysqli_query($conn,$query);
}
foreach ($html->find('div[class=cls_pagination]') as $e){
    foreach ($e->find('a') as $k){
        $val = $k->href;
        echo $val. '<br>';
        $query = "insert into links value ('$val')";
        mysqli_query($conn,$query);
    }
}
?>