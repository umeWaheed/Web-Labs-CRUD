<?php
$server = "mysql13.000webhost.com";
$username = "a6484287";
$password = "soft14WARE";
$db = "a6484287_assign2";

$conn= mysqli_connect("$server","$username","$password","$db");
if (!$conn)
    echo "error";
?>