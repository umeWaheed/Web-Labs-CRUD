<?php
include ('imagedb.php');
?>
<html>
<head>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <style>
        img{
            width:100%;
            height: 15em;
        }
        .panel{
            margin: 3%;
            background-color: dimgray;
            padding: 0;
        }
    </style>
</head>
<body>
<?php
$query = "select * from images";
$result = mysqli_query($conn,$query);
while ($row=mysqli_fetch_array($result)){
    ?>
    <div class="panel col-md-3">
        <div class="panel-body">
            <img src="<?php echo $row['path'] ?>" alt="image">
        </div>
        <div class="panel-footer">
            <p><?php echo $row['descrip'] ?></p>
        </div>
    </div>
    <?php
}
?>
</body>
</html>
